#!/bin/bash

repo_list="https://github.com/ipfs/go-ipfs
https://github.com/cjdelisle/cjdns
https://github.com/yggdrasil-network/yggdrasil-go
https://github.com/Bitmessage/PyBitmessage
https://github.com/popcorn-official/popcorn-desktop
https://github.com/andrejv/maxima
https://github.com/IntelRealSense/librealsense/tree/v1.12.1
https://github.com/mavlink/mavlink
https://github.com/ros/ros"

# check if mediainfo is installed
if [[ ! -x $(command -v git) ]]; then
    echo "git is not installed, install it now..."
    sudo apt-get install git -y
fi

for i in $repo_list; do
    git clone --depth 1 $i 
done