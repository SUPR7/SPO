#!/bin/bash

# check if mediainfo is installed
if [[ ! -x $(command -v mediainfo) ]]; then
    echo "mediainfo is not installed, install it now..."
    sudo apt-get install mediainfo -y
fi

get_file_info() {
    file=$(realpath "$1")
    filename=${file##*/}
    filepath=${file%/*}
    extension=${file##*.}
    size=$(wc -c "$file" | awk '{print $1/1024**2 " MB"}')
    modifytime=$(date -r "$file" "+%Y-%m-%d")
    if [[ $(mediainfo --Inform="General;%Duration%" "$file") ]]; then
        duration=$(awk 'BEGIN{print '$(mediainfo --Inform="General;%Duration%" "$file")'/1000 }')
    else
        duration="null"
    fi
    echo -e "$filepath,$filename,$extension,$size,$modifytime,$duration"
}

get_file_list() {
    file_list=$(ls -A1 "$1" 2>/dev/null)
    if [[ ! $file_list ]];then
        return
    fi
    for i in $1/*; do
        if [[ -d $i ]];then
            get_file_list "$i"
        elif [[ -f $i ]]; then
            get_file_info "$i"
        fi
    done
}

main() {
    printf "\xEF\xBB\xBF" > result.csv
    echo -e "File Path,File Name,Extension,Size,Modify Date,Duration (sec)" >> result.csv
    get_file_list $1 >> result.csv
}

case $@ in
    '')
        echo "No path specificed."
        echo -e "Usage:, $0 PATH"
        exit 1
        ;;
    *)
        if [[ ! -e $1 ]]; then
            echo "No such file or directory."
            exit 127
        else
            main "$1"
        fi
        ;;
esac